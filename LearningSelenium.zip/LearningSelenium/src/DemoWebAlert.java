import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.net.URLDecoder;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.concurrent.TimeUnit;


//pages 150-154 at G:\Testing\Lynda\Others\selenium-tutorial.pdf

public class DemoWebAlert {

    FirefoxDriver driver;

    public void invokebrowser() throws URISyntaxException {
        driver = new FirefoxDriver();
        CodeSource codeSource = DemoWebAlert.class.getProtectionDomain().getCodeSource();
        File jarFile = new File(codeSource.getLocation().toURI().getPath());
        String jarparent = jarFile.getParent();
        System.out.println("file://" + jarparent + "/DemoWebPopub.htm");
        driver.get("file://" + jarparent + "/DemoWebPopub.htm");
        driver.manage().window().maximize();

    }


    public void testWebAlert() throws InterruptedException {
        WebElement trybutton = driver.findElement(By.xpath("//button"));
        trybutton.click();

    //accepting javascript alert
        Alert a1 = driver.switchTo().alert();

//        Wait wait = new FluentWait(driver);
        //WebDriverWait wait = new WebDriverWait(driver, 10);
        Thread.sleep(5000);
        a1.accept();
        Thread.sleep(5000);
        System.out.println("You clicked OK");

        trybutton.click();
        Thread.sleep(5000);

        a1.dismiss();
        Thread.sleep(5000);
        System.out.println("You clicked Cancel");

        //a1.getText();
    }

    public static void main(String[] args) throws URISyntaxException {

        DemoWebAlert demoWebAlert1 = new DemoWebAlert();
        demoWebAlert1.invokebrowser();
        try {
            demoWebAlert1.testWebAlert();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }



}


